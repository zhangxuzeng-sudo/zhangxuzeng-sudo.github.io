import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {markdown,validatePost} from '../scripts/lib.mjs';
const root=path.resolve(import.meta.dirname,'..');
test('untrusted article content cannot inject executable HTML or javascript links',()=>{
  const html=markdown('<script>alert(1)</script>\n\n[unsafe](javascript:alert(1))\n\n[ok](https://example.com/?a=1&b=2)');
  assert(!html.includes('<script>'));assert(!html.includes('href="javascript:'));assert(html.includes('href="https://example.com/?a=1&amp;b=2"'));
  assert.throws(()=>validatePost({slug:'../../escape'}));
});
test('deployment under a project path has valid internal links; drafts and future posts remain out of HTML, JSON and feeds',()=>{
  const draft=JSON.parse(fs.readFileSync(path.join(root,'content/posts/microsoft-rpo.json'),'utf8'));
  const files=['qa-unpublished.json','qa-future.json'];
  fs.writeFileSync(path.join(root,'content/posts',files[0]),JSON.stringify({...draft,slug:'qa-unpublished',published:false,title_zh:'PRIVATE_DRAFT_SENTINEL'}));
  fs.writeFileSync(path.join(root,'content/posts',files[1]),JSON.stringify({...draft,slug:'qa-future',date:'2099-01-01',title_zh:'FUTURE_POST_SENTINEL'}));
  try {
    const run=spawnSync(process.execPath,['scripts/build.mjs'],{cwd:root,env:{...process.env,SITE_URL:'https://anonymous.example/journal',BASE_PATH:'/journal'},encoding:'utf8'});
    assert.equal(run.status,0,run.stderr);
    const dist=path.join(root,'dist');
    for(const file of fs.readdirSync(dist,{recursive:true}).filter(f=>/\.(html|xml|json)$/.test(f))){
      const text=fs.readFileSync(path.join(dist,file),'utf8');assert(!text.includes('PRIVATE_DRAFT_SENTINEL'));assert(!text.includes('FUTURE_POST_SENTINEL'));
      if(!file.endsWith('.html'))continue;
      for(const match of text.matchAll(/(?:href|src)="(\/journal\/[^"#?]*)/g)){
        const rel=match[1].slice('/journal/'.length);const resolved=path.join(dist,rel);assert(fs.existsSync(resolved),`broken ${match[1]} in ${file}`);
      }
    }
    assert(!fs.existsSync(path.join(dist,'zh/posts/qa-unpublished')));
    const rss=fs.readFileSync(path.join(dist,'en/feed.xml'),'utf8');assert(rss.includes('https://anonymous.example/journal/en/posts/'));assert.equal((rss.match(/<item>/g)||[]).length,4);
  } finally {for(const f of files)fs.unlinkSync(path.join(root,'content/posts',f));}
});
